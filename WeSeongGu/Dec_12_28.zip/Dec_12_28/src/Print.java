
public class Print {
	// 한귝어로 설꼐 -> 자바로 번역
	public static void main(String[] args) {
		// main 함수 영역
		System.out.println("위성구 첫 수업");
		System.out.println("어디에 사는가?: 노원구 수락산");
	}

}

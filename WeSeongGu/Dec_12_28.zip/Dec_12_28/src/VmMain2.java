
public class VmMain2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String resName = "김밥 천국";
		String address = "봉은 사로 117";
		int table = 10;
		float score = 4.5f;
		boolean book = true;
		System.out.println("-------------------------");
		System.out.println("식당 이름 : " + resName);
		System.out.println("식당 주소 : " + address);
		System.out.println("테이블 수 : " + table);
		System.out.println("평점 \t: " + score);
		System.out.println("예약 가능 : " + book);
		System.out.println("-------------------------");
	}

}

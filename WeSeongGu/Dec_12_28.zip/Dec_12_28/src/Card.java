
public class Card {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("*************************\n* 이름\t: %s         \t*\n","위성구");
		System.out.printf("* 휴대폰\t: %s\t*\n","010-1234-1234");
		System.out.printf("* 사는곳\t: %s          \t*\n*************************","노원");
		try {
			Thread.sleep(5000);			
		} catch (Exception e) {
		}
		//JAR (Java ARchive)
		//JRE가 있어야 함 java runtime enviroment
	}
}
